# =====================================================================
#  lista_python.py  —  LISTA 2: usa el list de Python y sus métodos
# ---------------------------------------------------------------------
#  Mismos 13 métodos que la Lista 1, con mucho menos código.
#  Encima de cada método: cuántas líneas de código tenía la versión
#  manual (lista_manual.py) y cuántas tiene esta versión.
#  Comprensiones obligatorias: buscar, buscar_binaria, eliminar_por_valor,
#  filtrar_mayores_de_edad y nombres_en_mayusculas.
# =====================================================================
from bisect import bisect_left
from pasajero import Pasajero


class ListaPasajerosPython:
    """Lista de pasajeros apoyada en el list de Python."""

    def __init__(self):
        self.pasajeros = []

    def añadir(self, pasajero):
        """Agrega al final si la cédula no existe. True si lo logró."""
        if self.buscar(pasajero.cedula) != -1:
            print("⚠ Ya existe un pasajero con esa cédula")
            return False
        self.pasajeros.append(pasajero)
        return True

    def listar(self):
        """Muestra los pasajeros con su posición."""
        if not self.pasajeros:
            print("(lista vacía)")
            return
        for i, pasajero in enumerate(self.pasajeros):
            print(f"[{i}] {pasajero}")

    # Líneas: manual 1 · Python 1
    def longitud(self):
        """Cuántos pasajeros hay."""
        return len(self.pasajeros)

    # Líneas: manual 16 · Python 8
    def insertar(self, posicion, pasajero):
        """Inserta en una posición. insert() corre los demás por ti."""
        if posicion < 0 or posicion > len(self.pasajeros):
            print("⚠ Posición no válida")
            return False
        if self.buscar(pasajero.cedula) != -1:
            print("⚠ Ya existe un pasajero con esa cédula")
            return False
        self.pasajeros.insert(posicion, pasajero)
        return True
    # RESPUESTA 3 (insertar): ¿insert() es tan barato como append()?
    # No. insert() debe correr a la derecha todos los elementos que están
    # desde la posición indicada para abrir el hueco. Es lo mismo que hace
    # mi while en la Lista 1, solo que Python lo hace en C y por eso es
    # más rápido, pero el trabajo es el mismo.
    # Complejidad: O(n). Insertar al inicio es el peor caso (se mueven los
    # n elementos) y al final es el mejor. En cambio append() agrega al
    # final sin mover nada y es O(1) amortizado.
    # Líneas: manual 7 · Python 5
    def buscar(self, cedula):
        """Búsqueda lineal con comprensión. Retorna la posición o -1."""
        posiciones = [i for i, p in enumerate(self.pasajeros)
                      if p.cedula == str(cedula)]
        if not posiciones:
            return -1
        return posiciones[0]

    # Líneas: manual 12 · Python 5
    def buscar_binaria(self, cedula):
        """Búsqueda binaria con bisect_left. Requiere lista ordenada."""
        cedulas = [p.cedula for p in self.pasajeros]
        posicion = bisect_left(cedulas, str(cedula))
        if posicion < len(cedulas) and cedulas[posicion] == str(cedula):
            return posicion
        return -1

    # Líneas: manual 7 · Python 7
    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        """Cambia nombre y edad. Reutiliza buscar."""
        posicion = self.buscar(cedula)
        if posicion == -1:
            print("⚠ No existe un pasajero con esa cédula")
            return False
        self.pasajeros[posicion].nombre = nuevo_nombre.strip().title()
        self.pasajeros[posicion].edad = int(nueva_edad)
        return True

    # Líneas: manual 9 · Python 4
    def eliminar_por_posicion(self, posicion):
        """Quita y retorna el pasajero con pop()."""
        if posicion < 0 or posicion >= len(self.pasajeros):
            print("⚠ Posición no válida")
            return None
        return self.pasajeros.pop(posicion)

    # Líneas: manual 6 · Python 7
    def eliminar_por_valor(self, cedula):
        """Elimina por cédula. Misma salida que la Lista 1 si no existe."""
        # FORMA 1 alternativa con remove:
        # posicion = self.buscar(cedula)
        # if posicion == -1:
        #     return False
        # self.pasajeros.remove(self.pasajeros[posicion])
        # return True

        # FORMA 2 obligatoria: comprensión de listas.
        antes = len(self.pasajeros)
        self.pasajeros = [p for p in self.pasajeros
                          if p.cedula != str(cedula)]
        if len(self.pasajeros) == antes:
            print("⚠ No existe un pasajero con esa cédula")
            return False
        return True

    # Líneas: manual 7 · Python 1
    def ordenar_asc(self):
        """Ordena ascendente por cédula."""
        self.pasajeros.sort(key=lambda p: p.cedula)
    # RESPUESTA 1 (ordenar): ¿Qué hace key= y qué pasa si lo quito?
    # key= es una función que le dice a sort() qué dato de cada elemento
    # debe usar para comparar. Aquí uso lambda p: p.cedula, así que cada
    # pasajero se ordena por su cédula.
    # Si lo quito, sort() intenta comparar dos objetos Pasajero con "<" y
    # da este error: TypeError: '<' not supported between instances of
    # 'Pasajero' and 'Pasajero'. Python no sabe si un pasajero es "menor"
    # que otro, a menos que yo se lo indique con key=.
    # Líneas: manual 7 · Python 1
    def ordenar_desc(self):
        """Ordena descendente por cédula."""
        self.pasajeros.sort(key=lambda p: p.cedula, reverse=True)

    # Líneas: manual 8 · Python 1
    def reversar(self):
        """Invierte el orden con reverse()."""
        self.pasajeros.reverse()

    # Líneas: manual 4 · Python 3
    def copiar(self):
        """Copia SUPERFICIAL: lista nueva, mismos objetos Pasajero."""
        nueva = ListaPasajerosPython()
        nueva.pasajeros = self.pasajeros.copy()
        return nueva
    # RESPUESTA 2 (copiar): ¿La copia es independiente del original?
    # Solo a medias. La copia es SUPERFICIAL (shallow): se crea una lista
    # nueva, pero con los mismos objetos Pasajero adentro.
    # - Si reverso, ordeno o elimino en la copia, el original NO cambia,
    #   porque son dos listas distintas.
    # - Si modifico un pasajero de la copia (copia.pasajeros[0].nombre = "X"),
    #   el original SÍ cambia, porque ambas listas apuntan al mismo objeto.
    # Para una copia totalmente independiente haría falta copy.deepcopy().
    # Mi Lista 1 se comporta igual, porque copiar() guarda las mismas
    # referencias.
    # Líneas: manual 5 · Python 4
    def filtrar_mayores_de_edad(self):
        """Lista nueva con los mayores de edad (comprensión)."""
        resultado = ListaPasajerosPython()
        resultado.pasajeros = [p for p in self.pasajeros
                               if p.es_mayor_de_edad()]
        return resultado

    # Líneas: manual 4 · Python 1
    def nombres_en_mayusculas(self):
        """Lista de nombres en mayúsculas (comprensión)."""
        return [p.nombre.upper() for p in self.pasajeros]
    
# CONCLUSIÓN: en la Lista 1 escribí cada algoritmo a mano (corrimientos,
# burbuja, búsqueda binaria) y los métodos tienen entre 5 y 16 líneas. Con
# el list de Python, métodos como ordenar, reversar y nombres_en_mayusculas
# quedan en 1 línea. Hacen lo mismo, pero Python trae el algoritmo hecho.