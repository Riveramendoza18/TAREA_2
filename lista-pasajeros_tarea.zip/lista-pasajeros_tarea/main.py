# Programa principal: Sistema de pasajeros con dos implementaciones de listas.
from pasajero import Pasajero
from lista_manual import ListaPasajerosManual
from lista_python import ListaPasajerosPython
from ejercicios import menu_ejercicios


def leer_entero(mensaje, minimo=None, maximo=None):
    while True:
        try:
            valor = int(input(mensaje))
            if minimo is not None and valor < minimo:
                print(f" El valor debe ser como mínimo {minimo}")
                continue
            if maximo is not None and valor > maximo:
                print(f" El valor debe ser como máximo {maximo}")
                continue
            return valor
        except ValueError:
            print(" Ingresa un número entero válido")


def leer_cedula():
    while True:
        cedula = input("Cédula (10 dígitos): ").strip()
        if cedula.isdigit() and len(cedula) == 10:
            return cedula
        print(" La cédula debe contener exactamente 10 dígitos")


def leer_pasajero():
    while True:
        nombre = input("Nombre: ").strip()
        if nombre:
            break
        print(" El nombre no puede estar vacío")
    cedula = leer_cedula()
    edad = leer_entero("Edad: ", 0, 120)
    # Pasajero no se modifica: el formato del nombre se arregla aquí.
    return Pasajero(nombre.title(), cedula, edad)


def cargar_datos_prueba(lista):
    # Se vacía la lista antes de cargar los cinco datos indicados en la guía.
    if isinstance(lista, ListaPasajerosManual):
        lista.datos = [None] * lista.capacidad
        lista.cantidad = 0
    else:
        lista.pasajeros = []

    datos = [
        ("Diana", "0923456789", 22),
        ("Ana", "0912345678", 28),
        ("Luis", "0987654321", 35),
        ("Beto", "0934567890", 16),
        ("Elena", "0901234567", 41),
    ]
    for nombre, cedula, edad in datos:
        lista.añadir(Pasajero(nombre, cedula, edad))
    print("Datos de prueba cargados")


def mostrar_menu_lista(titulo):
    print(f"\n========== {titulo} ==========")
    print("1. Añadir pasajero")
    print("2. Listar pasajeros")
    print("3. Insertar en una posición")
    print("4. Buscar por cédula (lineal)")
    print("5. Buscar por cédula (binaria; ordenar primero)")
    print("6. Modificar pasajero")
    print("7. Eliminar por posición")
    print("8. Eliminar por cédula")
    print("9. Ordenar ascendente por cédula")
    print("10. Ordenar descendente por cédula")
    print("11. Reversar lista")
    print("12. Copiar y reversar (comparar con original)")
    print("13. Mostrar longitud")
    print("14. Listar mayores de edad")
    print("15. Mostrar nombres en mayúsculas")
    print("C. Cargar datos de prueba")
    print("0. Volver")


def menu_lista(lista, titulo):
    while True:
        mostrar_menu_lista(titulo)
        op = input("Opción: ").strip().upper()

        if op == "1":
            pasajero = leer_pasajero()
            if lista.añadir(pasajero):
                print("Pasajero añadido")

        elif op == "2":
            lista.listar()

        elif op == "C":
            cargar_datos_prueba(lista)

        elif op == "3":
            posicion = leer_entero("Posición donde insertar: ", 0)
            pasajero = leer_pasajero()
            if lista.insertar(posicion, pasajero):
                print("✓ Pasajero insertado")

        elif op == "4":
            cedula = leer_cedula()
            posicion = lista.buscar(cedula)
            if posicion == -1:
                print("No existe")
            else:
                if isinstance(lista, ListaPasajerosManual):
                    pasajero = lista.datos[posicion]
                else:
                    pasajero = lista.pasajeros[posicion]
                print(f"Encontrado en [{posicion}]: {pasajero}")

        elif op == "5":
            print("Recuerda ordenar primero con la opción 9.")
            cedula = leer_cedula()
            posicion = lista.buscar_binaria(cedula)
            if posicion == -1:
                print("No existe")
            else:
                if isinstance(lista, ListaPasajerosManual):
                    pasajero = lista.datos[posicion]
                else:
                    pasajero = lista.pasajeros[posicion]
                print(f"Encontrado en [{posicion}]: {pasajero}")

        elif op == "6":
            cedula = leer_cedula()
            nombre = input("Nuevo nombre: ").strip()
            edad = leer_entero("Nueva edad: ", 0, 120)
            if not nombre:
                print("El nombre no puede estar vacío")
            elif lista.modificar(cedula, nombre, edad):
                print("Pasajero modificado")

        elif op == "7":
            posicion = leer_entero("Posición a eliminar: ", 0)
            quitado = lista.eliminar_por_posicion(posicion)
            if quitado is not None:
                print(f" Eliminado: {quitado}")

        elif op == "8":
            cedula = leer_cedula()
            if lista.eliminar_por_valor(cedula):
                print(" Pasajero eliminado")

        elif op == "9":
            lista.ordenar_asc()
            print(" Lista ordenada ascendentemente")
            lista.listar()

        elif op == "10":
            lista.ordenar_desc()
            print(" Lista ordenada descendentemente")
            lista.listar()

        elif op == "11":
            lista.reversar()
            print(" Lista reversada")
            lista.listar()

        elif op == "12":
            copia = lista.copiar()
            copia.reversar()
            print("--- COPIA (reversada) ---")
            copia.listar()
            print("--- ORIGINAL ---")
            lista.listar()

        elif op == "13":
            print(f"Hay {lista.longitud()} pasajeros")

        elif op == "14":
            mayores = lista.filtrar_mayores_de_edad()
            print("--- MAYORES DE EDAD ---")
            mayores.listar()

        elif op == "15":
            print(lista.nombres_en_mayusculas())

        elif op == "0":
            break
        else:
            print("Opción no válida")


def menu_lista1():
    menu_lista(ListaPasajerosManual(), "LISTA 1 · construida desde cero")


def menu_lista2():
    menu_lista(ListaPasajerosPython(), "LISTA 2 · list de Python")


def main():
    while True:
        print("\n╔══════════════════════════════════╗")
        print("║   TAREA LISTAS · PASAJEROS ✈     ║")
        print("╚══════════════════════════════════╝")
        print("1. Lista 1 (construida desde cero)")
        print("2. Lista 2 (list de Python)")
        print("3. Listar ejercicios")
        print("4. Salir")
        opcion = input("Opción: ").strip()

        if opcion == "1":
            menu_lista1()
        elif opcion == "2":
            menu_lista2()
        elif opcion == "3":
            menu_ejercicios()
        elif opcion == "4":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()
