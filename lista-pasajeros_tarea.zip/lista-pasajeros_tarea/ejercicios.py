# Ejercicios desarrollados y propuestos de la unidad de listas.

def ejercicio_t1():
    from lista_python import ListaPasajerosPython
    from pasajero import Pasajero

    print("\nT1 — CRUD de pasajeros con clase Pasajero + list")
    lista = ListaPasajerosPython()
    lista.añadir(Pasajero("Diana", "0923456789", 22))
    lista.añadir(Pasajero("Ana", "0912345678", 28))
    lista.añadir(Pasajero("Luis", "0987654321", 35))
    print("Después de añadir:")
    lista.listar()

    cedula = "0912345678"
    posicion = lista.buscar(cedula)
    print(f"Buscar {cedula}: posición {posicion}")
    if lista.modificar(cedula, "Ana María", 29):
        print("Pasajero modificado")
    if lista.eliminar_por_valor("0987654321"):
        print("Pasajero Luis eliminado")
    print("Después de modificar y eliminar:")
    lista.listar()
    lista.pasajeros.sort(key=lambda p: p.nombre)
    print("Ordenados por nombre:")
    lista.listar()


def ejercicio_t2():
    nombres = ["Ana", "Luis", "Diana", "Beto", "Elena"]
    notas = [8, 6, 10, 7, 5]
    print("\nT2 — Estadísticas de una lista de notas")

    # Versión manual: un recorrido, acumulador, campeón y contador.
    suma = 0
    maxima = notas[0]
    minima = notas[0]
    mejor_estudiante = nombres[0]
    aprobados_manual = 0
    for i in range(len(notas)):
        suma += notas[i]
        if notas[i] > maxima:
            maxima = notas[i]
            mejor_estudiante = nombres[i]
        if notas[i] < minima:
            minima = notas[i]
        if notas[i] >= 7:
            aprobados_manual += 1
    promedio = suma / len(notas)
    print(f"✋ Promedio {promedio:.2f} · Máx {maxima} ({mejor_estudiante}) · "
          f"Mín {minima} · Aprobados {aprobados_manual} de {len(notas)}")

    # Versión Python: funciones incorporadas y comprensión.
    maximo = max(notas)
    indice_mejor = notas.index(maximo)
    aprobados = [n for n in notas if n >= 7]
    print(f"🐍 Promedio {sum(notas) / len(notas):.2f} · Máx {maximo} "
          f"({nombres[indice_mejor]}) · Mín {min(notas)} · "
          f"Aprobados {len(aprobados)} de {len(notas)}")


def ejercicio_t3():
    lista = [5, 2, 8, 1, 9, 3, 7]
    print("\nT3 — Ordenar una lista (bubble sort)")
    manual = lista[:]
    n = len(manual)
    for vuelta in range(n - 1):
        hubo_swap = False
        for i in range(n - 1 - vuelta):
            if manual[i] > manual[i + 1]:
                aux = manual[i]
                manual[i] = manual[i + 1]
                manual[i + 1] = aux
                hubo_swap = True
        if not hubo_swap:
            break
    print("✋ Manual ascendente:", manual)
    print("🐍 Python ascendente:", sorted(lista))
    descendente = lista.copy()
    descendente.sort(reverse=True)
    print("🐍 Python descendente:", descendente)
    palabras = ["python", "a", "código", "el"]
    print("Palabras por longitud:", sorted(palabras, key=len))


def ejercicio_p1():
    lista = [1, 3, 2, 3, 4, 3, 5]
    valor = 3
    print("\nP1 — Contar apariciones de un valor")
    contador = 0
    for x in lista:
        if x == valor:
            contador += 1
    print(f"✋ Manual: {valor} aparece {contador} veces")
    print(f"🐍 count(): {valor} aparece {lista.count(valor)} veces")
    print(f"🧩 Comprensión: {len([x for x in lista if x == valor])} veces")


def ejercicio_p2():
    lista = [1, 2, 3, 4, 5]
    print("\nP2 — Invertir una lista")
    manual = []
    for i in range(len(lista) - 1, -1, -1):
        manual.append(lista[i])
    print("✋ Manual:", manual)
    print("🐍 Slicing:", lista[::-1])
    print("🐍 reversed():", list(reversed(lista)))
    print("🧩 Comprensión:",
          [lista[i] for i in range(len(lista) - 1, -1, -1)])


def ejercicio_p3():
    nums = [1, 3, 2, 3, 4, 1, 5, 2]
    print("\nP3 — Números únicos manteniendo el orden")
    unicos = []
    for numero in nums:
        if numero not in unicos:
            unicos.append(numero)
    print("✋ Manual:", unicos)
    print("🐍 dict.fromkeys():", list(dict.fromkeys(nums)))
    print("Nota: list(set(nums)) no garantiza conservar el orden original.")


def ejercicio_p4():
    nums = [5, 2, 9, 7, 9, 3, 8]
    print("\nP4 — Segundo mayor (sin ordenar toda la lista)")
    mayor = None
    segundo = None
    for numero in nums:
        if mayor is None or numero > mayor:
            if numero != mayor:
                segundo = mayor
            mayor = numero
        elif numero != mayor and (segundo is None or numero > segundo):
            segundo = numero
    print(f"✋ Manual: Mayor {mayor} · Segundo {segundo}")
    ordenados = sorted(set(nums))
    print(f"🐍 Python: Mayor {ordenados[-1]} · Segundo {ordenados[-2]}")


def ejercicio_p5():
    a = [1, 3, 5, 7]
    b = [2, 4, 6, 8, 10]
    print("\nP5 — Fusionar dos listas ordenadas (sin sort)")
    resultado = []
    i = 0
    j = 0
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            resultado.append(a[i])
            i += 1
        else:
            resultado.append(b[j])
            j += 1
    while i < len(a):
        resultado.append(a[i])
        i += 1
    while j < len(b):
        resultado.append(b[j])
        j += 1
    print("✋ Manual:", resultado)
    print("🐍 Python para comprobar:", sorted(a + b))


EJERCICIOS = [
    ("T1", "CRUD de pasajeros con clase Pasajero + list", "taller", ejercicio_t1),
    ("T2", "Estadísticas de una lista de notas", "taller", ejercicio_t2),
    ("T3", "Ordenar una lista (bubble sort)", "taller", ejercicio_t3),
    ("P1", "Contar apariciones de un valor", "propuesto", ejercicio_p1),
    ("P2", "Invertir una lista", "propuesto", ejercicio_p2),
    ("P3", "Números únicos", "propuesto", ejercicio_p3),
    ("P4", "Segundo mayor", "propuesto", ejercicio_p4),
    ("P5", "Fusionar dos listas ordenadas", "propuesto", ejercicio_p5),
]


def menu_ejercicios():
    taller = [e for e in EJERCICIOS if e[2] == "taller"]
    propuestos = [e for e in EJERCICIOS if e[2] == "propuesto"]
    while True:
        print("\n--- DESARROLLADOS (taller) ---")
        for ejercicio in taller:
            print(f"  {ejercicio[0]}. {ejercicio[1]}")
        print("--- PROPUESTOS ---")
        for ejercicio in propuestos:
            print(f"  {ejercicio[0]}. {ejercicio[1]}")
        print("  0. Volver")
        codigo = input("Código: ").strip().upper()
        if codigo == "0":
            break
        encontrados = [e for e in EJERCICIOS if e[0] == codigo]
        if encontrados:
            encontrados[0][3]()
        else:
            print("Código no válido")
