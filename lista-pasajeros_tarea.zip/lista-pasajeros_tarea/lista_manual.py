# =====================================================================
#  lista_manual.py  —  LISTA 1: construida DESDE CERO (como MiLista)
# ---------------------------------------------------------------------
#  Por dentro hay un arreglo de tamaño fijo con cajones vacíos (None).
#  Todo se resuelve solo con índices datos[i], while, for con range,
#  condiciones, una variable aux y el contador self.cantidad.
# =====================================================================
from pasajero import Pasajero


class ListaPasajerosManual:
    """Lista de pasajeros con capacidad fija, implementada a mano."""

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad   # cajones: Pasajero o None
        self.capacidad = capacidad        # cuántos cajones hay
        self.cantidad = 0                 # cuántos están ocupados

    def añadir(self, pasajero):
        """Pone el pasajero en el primer cajón libre. True si lo logró."""
        if self.cantidad == self.capacidad:
            print(" La lista está llena")
            return False
        if self.buscar(pasajero.cedula) != -1:     # cédula única
            print(" Ya existe un pasajero con esa cédula")
            return False
        self.datos[self.cantidad] = pasajero
        self.cantidad = self.cantidad + 1
        return True

    def listar(self):
        """Muestra los pasajeros con su posición."""
        if self.cantidad == 0:
            print("(lista vacía)")
            return
        for i in range(self.cantidad):
            print(f"[{i}] {self.datos[i]}")

    def longitud(self):
        """Cuántos pasajeros hay: el dato ya está guardado."""
        return self.cantidad

    def buscar(self, cedula):
        """Búsqueda lineal. Retorna la posición o -1."""
        cedula = str(cedula)
        i = 0
        while i < self.cantidad:           # solo hasta cantidad (el resto es None)
            if self.datos[i].cedula == cedula:
                return i
            i = i + 1
        return -1

    def modificar(self, cedula, nuevo_nombre, nueva_edad):
        """Cambia nombre y edad del pasajero. Reutiliza buscar."""
        posicion = self.buscar(cedula)
        if posicion == -1:
            print(" No existe un pasajero con esa cédula")
            return False
        self.datos[posicion].nombre = nuevo_nombre.strip().title()
        self.datos[posicion].edad = int(nueva_edad)
        return True

    def insertar(self, posicion, pasajero):
        """Abre un hueco corriendo a la DERECHA, de atrás hacia adelante."""
        if self.cantidad == self.capacidad:
            print(" La lista está llena")
            return False
        if posicion < 0 or posicion > self.cantidad:
            print(" Posición no válida")
            return False
        if self.buscar(pasajero.cedula) != -1:
            print("Ya existe un pasajero con esa cédula")
            return False
        i = self.cantidad
        while i > posicion:
            self.datos[i] = self.datos[i - 1]
            i = i - 1
        self.datos[posicion] = pasajero
        self.cantidad = self.cantidad + 1
        return True

    def eliminar_por_posicion(self, posicion):
        """Quita y retorna el pasajero, corriendo a la IZQUIERDA."""
        if posicion < 0 or posicion >= self.cantidad:
            print(" Posición no válida")
            return None
        eliminado = self.datos[posicion]
        for i in range(posicion, self.cantidad - 1):
            self.datos[i] = self.datos[i + 1]
        self.datos[self.cantidad - 1] = None       # limpiar el cajón sobrante
        self.cantidad = self.cantidad - 1
        return eliminado

    def eliminar_por_valor(self, cedula):
        """Busca por cédula y elimina por posición (reutiliza ambos)."""
        posicion = self.buscar(cedula)
        if posicion == -1:
            print(" No existe un pasajero con esa cédula")
            return False
        self.eliminar_por_posicion(posicion)
        return True

    def ordenar_asc(self):
        """Burbuja ascendente por cédula."""
        n = self.cantidad
        for vuelta in range(n - 1):
            for i in range(n - 1 - vuelta):
                if self.datos[i].cedula > self.datos[i + 1].cedula:
                    aux = self.datos[i]
                    self.datos[i] = self.datos[i + 1]
                    self.datos[i + 1] = aux

    def ordenar_desc(self):
        """Burbuja descendente por cédula."""
        n = self.cantidad
        for vuelta in range(n - 1):
            for i in range(n - 1 - vuelta):
                if self.datos[i].cedula < self.datos[i + 1].cedula:
                    aux = self.datos[i]
                    self.datos[i] = self.datos[i + 1]
                    self.datos[i + 1] = aux

    def buscar_binaria(self, cedula):
        """Búsqueda binaria. Requiere la lista ordenada ascendente."""
        cedula = str(cedula)
        izquierda = 0
        derecha = self.cantidad - 1
        while izquierda <= derecha:
            medio = (izquierda + derecha) // 2
            if self.datos[medio].cedula == cedula:
                return medio
            if self.datos[medio].cedula < cedula:
                izquierda = medio + 1
            else:
                derecha = medio - 1
        return -1

    def reversar(self):
        """Intercambia los extremos con dos punteros."""
        izquierda = 0
        derecha = self.cantidad - 1
        while izquierda < derecha:
            aux = self.datos[izquierda]
            self.datos[izquierda] = self.datos[derecha]
            self.datos[derecha] = aux
            izquierda = izquierda + 1
            derecha = derecha - 1

    def copiar(self):
        """Lista nueva con los mismos pasajeros (el original no cambia)."""
        nueva = ListaPasajerosManual(self.capacidad)
        for i in range(self.cantidad):
            nueva.añadir(self.datos[i])
        return nueva

    def filtrar_mayores_de_edad(self):
        """Retorna una lista nueva solo con los mayores de edad."""
        resultado = ListaPasajerosManual(self.capacidad)
        for i in range(self.cantidad):
            if self.datos[i].es_mayor_de_edad():
                resultado.añadir(self.datos[i])
        return resultado

    def nombres_en_mayusculas(self):
        """Arreglo nuevo con los nombres en mayúsculas (no toca los objetos)."""
        resultado = [None] * self.cantidad
        for i in range(self.cantidad):
            resultado[i] = self.datos[i].nombre.upper()
        return resultado
